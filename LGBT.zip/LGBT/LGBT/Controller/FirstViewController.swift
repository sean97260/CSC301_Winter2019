//
//  FirstViewController.swift
//  LGBT
//
//  Created by NOKEYUAN on 2019-03-06.
//  Copyright © 2019 NOKEYUAN. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tableview: UITableView!
    var info = [Info]()
    
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return info.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableview.dequeueReusableCell(withIdentifier: "InfoCell", for: indexPath) as? InfoCell{
            let thisInfo = info[indexPath.row]
            cell.updateUI(myInfo: thisInfo)
            return cell
        }else{
            return UITableViewCell()
        }
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        //testing for event posted
        let event1 = Info(imageURL: "http://cdn.youthline.ca/wp-content/uploads/2016/08/1424_YL_youthawards_poster.jpg", eventInfo: "this event")

        let event2 = Info(imageURL: "http://cdn.youthline.ca/wp-content/uploads/2016/08/1424_YL_youthawards_poster.jpg", eventInfo: "this event")

        let event3 = Info(imageURL: "http://cdn.youthline.ca/wp-content/uploads/2016/08/1424_YL_youthawards_poster.jpg", eventInfo: "this event")

        let event4 = Info(imageURL: "http://cdn.youthline.ca/wp-content/uploads/2016/08/1424_YL_youthawards_poster.jpg", eventInfo: "this event")

        info.append(event1)
        info.append(event2)
        info.append(event3)
        info.append(event4)

//        // Do any additional setup after loading the view, typically from a nib.
//        self.tableview.delegate = self
//        self.tableview.dataSource = self
    }
    
    

}

