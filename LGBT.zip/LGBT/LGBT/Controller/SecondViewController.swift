//
//  SecondViewController.swift
//  LGBT
//
//  Created by NOKEYUAN on 2019-03-06.
//  Copyright © 2019 NOKEYUAN. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

