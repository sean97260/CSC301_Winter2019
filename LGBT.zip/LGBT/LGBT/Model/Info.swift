//
//  Info.swift
//  LGBT
//
//  Created by NOKEYUAN on 2019-03-06.
//  Copyright © 2019 NOKEYUAN. All rights reserved.
//

import Foundation

class Info {
    private var _imageURL: String!
    private var _eventInfo: String!
    
    //getter function
    var imageURL:String{
        return  _imageURL
    }
    
    var eventInfo:String{
        return _eventInfo
    }
    
    init(imageURL:String, eventInfo:String) {
        _imageURL = imageURL
        _eventInfo = eventInfo
    }
    

}
