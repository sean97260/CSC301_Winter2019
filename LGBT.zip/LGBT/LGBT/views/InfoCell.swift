//
//  InfoCell.swift
//  LGBT
//
//  Created by NOKEYUAN on 2019-03-06.
//  Copyright © 2019 NOKEYUAN. All rights reserved.
//

import UIKit

class InfoCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    //event information for each cell
    @IBOutlet weak var eventInfo: UILabel!
    
    //preview image for each events
    @IBOutlet weak var eventPreview: UIImageView!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func updateUI(myInfo: Info){
        //update the info
        eventInfo.text = myInfo.eventInfo
        //update the image
        
        
    }

}
